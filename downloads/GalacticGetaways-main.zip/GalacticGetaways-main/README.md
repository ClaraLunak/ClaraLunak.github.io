# GalacticGetaways
Detta är ett gruppprojekt för kursen "Klientprogrammering för webbsystem". Projektet är gjord mha Java, HTML/CSS samt Vue 
